--
-- Database: `shoes_test`
--
CREATE DATABASE IF NOT EXISTS `shoes_test` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `shoes_test`;

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `brand_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `brands_stores`
--

CREATE TABLE `brands_stores` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `brand_id` int(11) DEFAULT NULL,
  `store_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `brands_stores`
--

INSERT INTO `brands_stores` (`id`, `brand_id`, `store_id`) VALUES
(1, 149, 108),
(2, 154, 113),
(3, 159, 118),
(4, 160, 119),
(5, 160, 120),
(6, 165, 125),
(7, 166, 126),
(8, 166, 127),
(9, 171, 132),
(10, 172, 133),
(11, 172, 134),
(12, 177, 139),
(13, 178, 140),
(14, 178, 141),
(15, 146, 183),
(16, 147, 184),
(17, 148, 184),
(18, 153, 189),
(19, 154, 190),
(20, 155, 190),
(21, 160, 191),
(22, 161, 192),
(23, 161, 193),
(24, 162, 198),
(25, 163, 199),
(26, 164, 199),
(27, 169, 200),
(28, 170, 201),
(29, 170, 202),
(30, 171, 207),
(31, 172, 208),
(32, 173, 208),
(33, 178, 211),
(34, 179, 212),
(35, 179, 213),
(36, 180, 218),
(37, 181, 219),
(38, 182, 219),
(39, 187, 222),
(40, 188, 223),
(41, 188, 224),
(42, 189, 229),
(43, 190, 230),
(44, 191, 230),
(45, 196, 234),
(46, 197, 235),
(47, 197, 236),
(48, 198, 241),
(49, 199, 242),
(50, 200, 242),
(51, 205, 246),
(52, 206, 247),
(53, 206, 248),
(54, 207, 253),
(55, 208, 254),
(56, 209, 254),
(57, 214, 258),
(58, 215, 259),
(59, 215, 260),
(60, 216, 265),
(61, 217, 266),
(62, 218, 266),
(63, 223, 270),
(64, 224, 271),
(65, 224, 272),
(66, 225, 277),
(67, 226, 278),
(68, 227, 278),
(69, 232, 282),
(70, 233, 283),
(71, 233, 284),
(72, 234, 289),
(73, 235, 290),
(74, 236, 290);

-- --------------------------------------------------------

--
-- Table structure for table `stores`
--

CREATE TABLE `stores` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `store_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `brands_stores`
--
ALTER TABLE `brands_stores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `stores`
--
ALTER TABLE `stores`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=237;
--
-- AUTO_INCREMENT for table `brands_stores`
--
ALTER TABLE `brands_stores`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=75;
--
-- AUTO_INCREMENT for table `stores`
--
ALTER TABLE `stores`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=294;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
